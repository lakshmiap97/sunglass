const user = require("../models/userModel")
const otpHelper = require('../helper/otpHelper')
const signupHelper = require('../helper/signupHelper')
const bcrypt = require('bcrypt')
const productHelper=require('../helper/productHelper')
const categoryHelper=require("../helper/categoryHelper")
const category=require('../models/categoryModel')
const productModel = require("../models/productModel")
const loginLoad = (req, res) => {
    try {
        res.render('login')
    } catch (error) {
        console.log(error);
    }
}

const createUser = async (req, res) => {
    try {
        const userIn = {
            name: req.body.name,
            email: req.body.email,
            mobile: req.body.mobile,
            password: req.body.password,
            isadmin: 0
        }

        console.log(userIn);
        const result = await user.create(userIn)
        if (result) {
            res.redirect("/otp-verification")
        }
    } catch (error) {
        if (error) {
            console.log(error);
            res.redirect("/register")
        }
    }
}
const checkUser = async (req, res) => {
    console.log("Entered in to checkUser");
    const logemail = req.body.email
    const logpassword = req.body.password
    try {
        const loggeduser = await user.findOne({
            email: logemail,
        })
        if(loggeduser.isActive){
            bcrypt.compare(logpassword, loggeduser.password).then((response)=>{
                console.log("Entered in to checkUser");
                req.session.user = loggeduser._id
    //             // console.log(req.session.user)
                res.redirect("/home-page")
                console.log(loggeduser);
            })
            .catch((error)=>{console.log(error)})
        }else{
            res.render('login',{blocked:"user has been blocked"})
        }
        
//         // console.log(loggeduser);
//         // if (success) {
//         //     console.log("Entered in to checkUser");
//         //     req.session.user = loggeduser._id
//         //     console.log(req.session.user)
//         //     res.redirect("/home-page")
//             // console.log(loggeduser);
//         // } else {
//         //     res.redirect("/")
//         // }




    } catch (err) {
        console.log(err.message);
    }
}




const Loadregister = (req, res) => {
    try {
        res.render('register')
    } catch (error) {
        console.log(error);
    }
}
const loadotp = (req, res) => {
    try {
        const message = req.flash("error");
        
        res.render("otp-verification",{message:message})
    } catch (error) {
        console.log(error);
    }
}
// const loadhome=(req,res)=>{
//     try{
//         res.render("home-page")
//     }catch(error){
//         console.log(error);
//     }
// }
const loadforgot = (req, res) => {
    try {
        res.render("forgot-password")
    } catch (error) {
        console.log(error);
    }
}

const insertUserWithVerify = async function (req, res) {
    try {
        const sendedOtp = req.session.otp
        const verifyOtp = req.body.otp
        console.log(sendedOtp);
        console.log(verifyOtp);
        console.log("start checking");


        if (sendedOtp === verifyOtp && Date.now() < req.session.otpExpiry) {
            console.log("otp entered before time expires");
            req.session.otpMatched = true
            console.log("request in insert user");


            const userData = req.session.insertData
            console.log(userData);
            const respons = await signupHelper.doSignUp(userData)
            console.log(respons);
            if (!respons.status) {
                const error = respons.message
                req.flash("message", error)
                return res.redirect("/register")
            } else {
                const message = respons.message
                // req.flash("message",message)
                return res.redirect('/login')
            }
        } else {
            console.log("failed otp verification");
            req.session.otpExpiry = false
            req.flash("error", "Incorrect OTP entered. Please enter the correct OTP.");
            res.redirect('/otp-verification')
        }
    } catch (error) {
        console.error(error);
        return res.redirect("/register")
    }

}
const Loaduserproduct = async (req, res) => {
    const id=req.params.id
    const userData=req.session.user
    const product = await productModel
    .findById({_id:id})
    .populate("category")
    .lean()
    console.log(product.image);
    
       
        res.render('user-productpage', {
         product,
         userData })
   
}



// const logoutUser = async (req, res) => {
//     try {
//         if (req.session.user) {
//             req.session.destroy((error) => {
//                 if (error) {
//                     res.redirect('/home-page')
//                 } else {
//                     res.redirect("/home-page")
//                 }
//             })
//         } else {
//             res.redirect("/home-page")
//         }
//     } catch (error) {
//         console.log(error);

//     }
// }

const logoutUser = async (req, res) => {
    try {
        if (req.session.user) {
            req.session.destroy((error) => {
                if (error) {
                    console.log("Error destroying session:", error);
                }
                res.redirect('/home-page');
            });
        } else {
            res.redirect("/home-page");
        }
    } catch (error) {
        console.error("Error logging out user:", error);
        res.redirect("/home-page");
    }
}

const isAuthenticated = (req, res, next) => {
    if (req.session && req.session.user) {
        return next()
    } else {
        res.redirect('/home-page')
    }
}

// const loadhomepage = (req, res) => {
//     try {
//         console.log(req.session.user)
//         if (req.session.user) {
//             res.render("home-page", { users: req.session.user })
//         } else {

//             res.render("home-page")
//         }
//     } catch (error) {
//         console.log(error);
//     }
// }

const loadhomepage = async(req,res)=>{
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    try{
      const users =  req.session.user;
      const categories = await categoryHelper.getAllcategory();
      const Products = await productHelper.getAllActiveProducts();
     
  console.log(Products);
      if(users){
        res.render("home-page", {
          products: Products ,
          users,
          categories
        
        });
      }else{
        res.render("home-page", {
          products: Products ,
          categories
          
        });     
      }
      
     
  
    }catch(error){
      console.log(error)
    }
  }



  const productDetails = async(req,res)=>{
    try{
     const pdata = req.query._id
     
     console.log(pdata);
    }catch(err){
        console.log(err);
    }
  }

  const loadAccount=async(req,res)=>{
    try {
        const users=req.session.user
        if(users){
            res.render('user-account',{users:users})
        }else{
            res.render('user-account')
        }
       
    } catch (error) {
        console.log(error);
    }
  }
module.exports = {
    loginLoad,
    createUser,
    Loadregister,
    loadotp,
    checkUser,
    loadforgot,
    insertUserWithVerify,
    Loaduserproduct,
    logoutUser,
    isAuthenticated,
    loadhomepage,
    productDetails,
    loadAccount

}