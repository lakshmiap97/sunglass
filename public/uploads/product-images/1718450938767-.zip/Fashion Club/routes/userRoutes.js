const express=require('express')
const otpHelper = require('../helper/otpHelper')

const router=express.Router()

const userController=require('../controllers/userController')

const userMiddleware=require('../middlewares/userMiddleware')
router.get('/register',userController.Loadregister)
router.get('/',userController.loadhomepage)
router.get('/otp-verification',userController.loadotp)
router.get('/forgot-password',userController.loadforgot)
router.post('/login',userController.checkUser)
router.get('/login',userMiddleware.islogin,userController.loginLoad)
router.get('/home-page',userController.loadhomepage)
router.get('/user-productpage/:id',userMiddleware.islogout,userController.Loaduserproduct)
router.get('/logout',userMiddleware.islogout,userController.logoutUser)
router.get('/productView',userController.productDetails)
router.get('/user-account',userController.loadAccount)


router.post('/resendOTP',otpHelper.resendOtp)
router.post('/otp-verification',userController.insertUserWithVerify)
router.post('/register',otpHelper.sentotp)




module.exports=router