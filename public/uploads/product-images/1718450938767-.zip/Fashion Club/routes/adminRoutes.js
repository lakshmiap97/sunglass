const express = require('express')
const app = express()
const router = express.Router()
const nocache = require('nocache')
const categoryHelper = require("../helper/categoryHelper")
const adminController = require('../controllers/adminController')
const multer = require('../middlewares/multer')
const productHelper = require('../helper/productHelper')
const adminMiddleware = require('../middlewares/adminMiddleware')

router.get('/product-list',adminMiddleware.islogoutAdmin, adminController.Loadproductlists)
router.get('/admin-userEdit',adminMiddleware.islogoutAdmin, adminController.LoadadminuserEdit)
router.get('/admin-category',adminMiddleware.islogoutAdmin, adminController.LoadadminCategories);
router.get('/admin-login', adminMiddleware.isloginAdmin, adminController.Adminloginload)
router.get("/admin-editcategory",adminMiddleware.islogoutAdmin, adminController.loadEditcategory)
router.get("/admin-catEditor/:id",adminMiddleware.islogoutAdmin, adminController.modalLoader)
router.get('/adminadd-products',adminMiddleware.islogoutAdmin, adminController.LoadAddproduct)
router.get('/admin-dashboard',adminMiddleware.islogoutAdmin, adminController.Loaddashboard)
router.get("/product-listEdit/:id",adminMiddleware.islogoutAdmin, adminController.editProductLoad);
router.get('/logoutAdmin', adminMiddleware.islogoutAdmin, adminController.logoutAdmin)


router.patch("/blockuser", adminController.blockUser)
router.patch("/listunlist", adminController.listunlist)
router.patch("/editcategory", categoryHelper.editedSave)
router.patch('/deleteproduct/:id', adminController.softdeleteproduct)
router.put('/addcategory', adminController.addcategory)
router.put("/editProduct/:id", multer.productUpload.array("images"), productHelper.editProductPost)
router.post('/addproduct', multer.productUpload.array("images"), adminController.addProduct)
router.post('/admin-login', adminController.checkAdmin)



module.exports = router